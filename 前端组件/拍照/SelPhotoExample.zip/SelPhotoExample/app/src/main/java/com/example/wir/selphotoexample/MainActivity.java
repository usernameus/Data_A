package com.example.wir.selphotoexample;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.wir.selphotoexample.Clipimage.ClipOptions;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //动态获取权限监听
    private static PermissionListener mListener;

    private static final int CAMERA_REQUEST_CODE = 1;
    private static final int ALBUM_REQUEST_CODE = 3; //从相册选择
    private static final int REQUEST_CAMERA = 5;
    private static final int CLIP_IMAGE_REQUEST_CODE = 2;  //裁图结果
    private File cameraFile;
    private File cropFile;

    private Uri imageUri;
    private String path;

    String finalImg;
    TextView tvSel;
    ImageView ivPhoto;
    CheckBox cbIsClip;
    private PhotoSelectDialog mPhotoDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvSel= (TextView) findViewById(R.id.btn_sel);
        ivPhoto= (ImageView) findViewById(R.id.iv_photo);
        cbIsClip= (CheckBox) findViewById(R.id.cb_is_clip);
        mPhotoDialog = new PhotoSelectDialog(this);
        tvSel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPhotoDialog.show(new PhotoSelectDialog.OnPhotoListener() {
                    @Override
                    public void takePhoto() {
                        takePhotoForCamera();
                    }

                    @Override
                    public void choosePhotos() {
                        takePhotoForAlbum();
                    }

                    @Override
                    public void cancel() {

                    }
                });
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CAMERA) {
                cropFile = FileUtil.getCacheFile(new File(FileUtil.getDiskCacheDir(this)), System.currentTimeMillis() + "crop_image.jpg");
                path = cropFile.getAbsolutePath();
                if (cbIsClip.isChecked()) {
//                BitmapUtil.LoadImg(mContext, path, personalCiAvatar);
                    ClipPhotoAct.getClipOptions().aspectX(1).aspectY(1)
                            .maxWidth(FileUtil.getScreenWidth(this))
                            .inputPath(cameraFile.getAbsolutePath())
                            .outputPath(path)
                            .startForResult(this, CLIP_IMAGE_REQUEST_CODE);
                }else {
                    /**
                     * 这里要选择 cameraFile.getAbsolutePath()
                     */
                    BitmapUtil.LoadImg(getBaseContext(), cameraFile.getAbsolutePath(), ivPhoto);
                }
            } else if (requestCode == ALBUM_REQUEST_CODE) {
                cropFile = FileUtil.getCacheFile(new File(FileUtil.getDiskCacheDir(this)), System.currentTimeMillis() + "crop_image.jpg");
                path = cropFile.getAbsolutePath();
                if (cbIsClip.isChecked()) {
                ClipPhotoAct.getClipOptions().aspectX(1).aspectY(1)
                        .maxWidth(FileUtil.getScreenWidth(this))
                        .inputPath(getPath(data.getData()))
                        .outputPath(path)
                        .startForResult(this, CLIP_IMAGE_REQUEST_CODE);
                }else {/**
                 * 这里要选择 getPath(data.getData())
                 */
                    BitmapUtil.LoadImg(getBaseContext(), getPath(data.getData()), ivPhoto);
                }
            } else if (requestCode == CLIP_IMAGE_REQUEST_CODE) {
                if (data != null) {
                    path = ClipOptions.createFromBundle(data).getOutputPath();
                    /**
                     * File finalFile = FileUtil.bytesToImageFile(path, getBaseContext());
                     * 这是压缩文件的
                     */
//                    File finalFile = FileUtil.bytesToImageFile(path, getBaseContext());
//                    BitmapUtil.LoadImg(getBaseContext(), finalFile.getAbsolutePath(), ivPhoto);
                    BitmapUtil.LoadImg(getBaseContext(), path, ivPhoto);
//                    List<File> files = new ArrayList<>();
//                    files.add(finalFile);
//                    loadDialog.showDialog();
//                    BitmapUtil.sendMultipart(files, this);
                }
            }
        }
    }
    private String getPath(Uri uri) {
        String[] projection = {MediaStore.Video.Media.DATA};
        Cursor cursor = getBaseContext().getContentResolver().query(uri, projection, null, null, null);
        int column_index = cursor
                .getColumnIndexOrThrow(MediaStore.Audio.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    private void takePhotoForAlbum() {

        String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
        requestRuntimePermission(permissions, new PermissionListener() {
            @Override
            public void onGranted() {
                openAlbum();
            }

            @Override
            public void onDenied(List<String> deniedPermission) {
                //没有获取到权限，什么也不执行，看你心情
            }
        });
    }

    private void openAlbum() {
//        Intent intent = new Intent("android.intent.action.GET_CONTENT");
//        intent.setType("image/*");
//        startActivityForResult(intent, CHOOSE_PHOTO); // 打开相册
        Intent intent2 = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);//调用android的图库
        (MainActivity.this).startActivityForResult(intent2, ALBUM_REQUEST_CODE);
    }
    private void openCamera() {

        cameraFile = FileUtil.getCacheFile(new File(FileUtil.getDiskCacheDir(this)), "output_image.jpg");
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            imageUri = Uri.fromFile(cameraFile);
        } else {

            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            imageUri = FileProvider.getUriForFile(MainActivity.this, "com.example.wir.selphotoexample.fileprovider", cameraFile);

        }
        // 启动相机程序
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(intent, REQUEST_CAMERA);
    }
    private void takePhotoForCamera() {
        String[] permissions = {Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
        requestRuntimePermission(permissions, new PermissionListener() {
            @Override
            public void onGranted() {
                openCamera();
            }

            @Override
            public void onDenied(List<String> deniedPermission) {
                //有权限被拒绝，什么也不做好了，看你心情
            }
        });

    }

    //andrpoid 6.0 需要写运行时权限
    public void requestRuntimePermission(String[] permissions, PermissionListener listener) {

        mListener = listener;
        List<String> permissionList = new ArrayList<>();
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(MainActivity.this, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionList.add(permission);
            }
        }
        if (!permissionList.isEmpty()) {
            ActivityCompat.requestPermissions(MainActivity.this, permissionList.toArray(new String[permissionList.size()]), 1);
        } else {
            mListener.onGranted();
        }
    }

    @TargetApi(23)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0) {
                    List<String> deniedPermissions = new ArrayList<>();
                    for (int i = 0; i < grantResults.length; i++) {
                        int grantResult = grantResults[i];
                        String permission = permissions[i];
                        if (grantResult != PackageManager.PERMISSION_GRANTED) {
                            deniedPermissions.add(permission);
                        }
                    }
                    if (deniedPermissions.isEmpty()) {
                        mListener.onGranted();
                    } else {
                        mListener.onDenied(deniedPermissions);
                    }
                }
                break;
            default:
                break;
        }
    }


    public interface PermissionListener {
        /**
         * 成功获取权限
         */
        void onGranted();

        /**
         * 为获取权限
         *
         * @param deniedPermission
         */
        void onDenied(List<String> deniedPermission);

    }


}
