package com.example.wir.selphotoexample;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * Created by xiaoshu on 2017/3/28 0028.
 * 图片选择弹窗
 */

public class PhotoSelectDialog implements View.OnClickListener {

    private TextView mTvTakePhoto;
    private TextView mTvChoosePhoto;
    private TextView mTvCancel;
    private CustomDialog mDialog;
    private OnPhotoListener mListener;

    public PhotoSelectDialog(Context context) {
        initView(context);
    }

    private void initView(Context context) {
        View contentView = LayoutInflater.from(context).inflate(R.layout.dialog_select_photo, null);
        mTvTakePhoto = (TextView) contentView.findViewById(R.id.tv_dialog_take_photo);
        mTvChoosePhoto = (TextView) contentView.findViewById(R.id.tv_dialog_choose_from_photos);
        mTvCancel = (TextView) contentView.findViewById(R.id.tv_dialog_cancel);
        mTvTakePhoto.setOnClickListener(this);
        mTvCancel.setOnClickListener(this);
        mTvChoosePhoto.setOnClickListener(this);
        mDialog = new CustomDialog(context).setContentView(contentView, ViewGroup.LayoutParams.MATCH_PARENT
                , ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).setCancelable(true)
                .setCanceledOnTouchOutside(true);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_dialog_take_photo:
                if (mListener != null) {
                    mListener.takePhoto();
                }
                dismiss();
                break;
            case R.id.tv_dialog_choose_from_photos:
                if (mListener != null) {
                    mListener.choosePhotos();
                }
                dismiss();
                break;
            case R.id.tv_dialog_cancel:
                if (mListener != null) {
                    mListener.cancel();
                }
                dismiss();
                break;
        }
    }

    public void show(OnPhotoListener listener) {
        this.mListener = listener;
        if (!mDialog.isShowing()) {
            mDialog.show();
        }
    }

    public void dismiss(){
        if (mDialog.isShowing()){
            mDialog.dismiss();
        }
    }

    public interface OnPhotoListener {
        void takePhoto();

        void choosePhotos();

        void cancel();
    }
}
