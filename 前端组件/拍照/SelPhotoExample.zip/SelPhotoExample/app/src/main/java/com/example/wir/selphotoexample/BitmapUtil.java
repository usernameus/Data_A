package com.example.wir.selphotoexample;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.util.Log;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import java.io.IOException;

/**
 * Created by Administrator on 2017/11/20.
 */

public class BitmapUtil {
    static int loadingImage = R.mipmap.img_load;//加载中的图片
    static int failImage = R.mipmap.img_load;//加载失败的图片
    /**
     * 通过path获取bitmap对象
     *
     * @param path
     * @return
     */
    public static Bitmap getBitmap(String path, BitmapFactory.Options options) {
        try {
            Bitmap temp = BitmapFactory.decodeFile(path, options);
            // 得到图片的旋转角度
            int degree = getBitmapDegree(path);
            // 根据旋转角度，生成旋转矩阵
            Matrix matrix = new Matrix();
            matrix.postRotate(degree);
            Bitmap bitmap=Bitmap.createBitmap(temp, 0, 0, temp.getWidth(), temp.getHeight(), matrix, true);
            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 获取原始图片的角度（解决三星手机拍照后图片是横着的问题）
     *
     * @param path 图片的绝对路径
     * @return 原始图片的角度
     */
    public static int getBitmapDegree(String path) {
        int degree = 0;
        try {
            // 从指定路径下读取图片，并获取其EXIF信息
            ExifInterface exifInterface = new ExifInterface(path);
            // 获取图片的旋转信息
            int orientation = exifInterface.getAttributeInt(ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL);
            Log.e("jxf", "orientation" + orientation);
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    degree = 90;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    degree = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    degree = 270;
                    break;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return degree;
    }
    /**
     * 实现Glide加载图片
     *
     * @param context
     * @param uri
     * @param view
     */
    public static void LoadImg(Context context, String uri, ImageView view) {
        Glide.with(context)
                .load(uri)
                .asBitmap()
                .placeholder(loadingImage)//未加载完成
                .error(failImage) //加载失败
                .into(view);
    }

}
