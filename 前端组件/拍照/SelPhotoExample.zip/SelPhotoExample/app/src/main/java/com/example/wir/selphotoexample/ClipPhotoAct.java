package com.example.wir.selphotoexample;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

import com.example.wir.selphotoexample.Clipimage.ClipImageView;
import com.example.wir.selphotoexample.Clipimage.ClipOptions;
import com.example.wir.selphotoexample.Clipimage.ClipUtils;

/**
 * Created by Administrator on 2017/11/20.
 */

public class ClipPhotoAct extends Activity {
    TextView mTvCancel;
    TextView mTvSure;
    ClipImageView mClipImageView;
    public ProgressDialog mDialog;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_crop_photo);
        init();
        initData();
    }


    private void init() {
        mTvCancel= (TextView) findViewById(R.id.tv_crop_cancel);
        mTvSure= (TextView) findViewById(R.id.tv_crop_sure);
        mClipImageView= (ClipImageView) findViewById(R.id.clip_image_view);
        mTvCancel.setOnClickListener(clickListener);
        mTvSure.setOnClickListener(clickListener);
        mDialog = new ProgressDialog(this);
        mDialog.setMessage("正在剪裁图片，请稍候...");
    }
    private void initData() {
        ClipOptions clipOptions = ClipOptions.createFromBundle(getIntent());
        ClipUtils.getInstance().mOutput = clipOptions.getOutputPath();
        ClipUtils.getInstance().mInput = clipOptions.getInputPath();
        ClipUtils.getInstance().mMaxWidth = clipOptions.getMaxWidth();
        ClipUtils.getInstance().activityClass = clipOptions.getActivityClass();
        mClipImageView.setAspect(clipOptions.getAspectX(), clipOptions.getAspectY());
        mClipImageView.setTip(clipOptions.getTip());
        mClipImageView.setMaxOutputWidth(ClipUtils.getInstance().mMaxWidth);

        ClipUtils.getInstance().setImageAndClipParams(mClipImageView); //大图裁剪
    }
    public static ClipOptions getClipOptions() {
        return new ClipOptions();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mDialog.isShowing())
            mDialog.dismiss();
    }

    private View.OnClickListener clickListener=new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.tv_crop_cancel:
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            finish();
                        }
                    }, 1000);
                    break;
                case R.id.tv_crop_sure:
                    ClipUtils.getInstance().clipImage(ClipPhotoAct.this, mDialog, mClipImageView);
                    break;
            }
        }
    };
}
